---
name: reproduce-janusvln-base
description: Reproduce and verify the open-source JanusVLN Base checkpoint on the R2R val_unseen split with 8 GPUs, detached background execution, independent JSONL metric recomputation, and comparison against the paper. Use when Codex needs to deploy, rerun, monitor, audit, or document JanusVLN Base evaluation on aigc_1 or a compatible Linux GPU server.
---

# Reproduce JanusVLN Base

Reproduce the Base checkpoint with the already validated 8-GPU recipe. Keep server-specific paths configurable and preserve evidence needed for an audit.

## Read the reference

Read [references/reproduction-report.md](references/reproduction-report.md) before preparing or interpreting a run. It records the validated commit, environment, dataset layout, exact launch parameters, paper targets, measured results, and known caveats.

## Workflow

1. Connect to the requested server with its configured remote-access skill or SSH mechanism. On `aigc_1`, reuse an existing live session instead of opening a duplicate.
2. Inspect the repository, model, datasets, GPUs, result directory, log, and running processes before changing anything. Preserve unrelated files and dirty worktree changes.
3. Require the repository commit `64ac8373c1e3c4a810a999cad536f633f2277d68`. If the worktree is dirty, do not switch commits or reset it; report the conflict.
4. Require the Base checkpoint `misstl/JanusVLN_Base`, revision `33f932a4ea6bdc34afca9f5b79a8b4537cd02509`.
5. Match the tested package versions and dataset layout in the reference. Install `fastdtw==0.3.4`; it is needed although the upstream requirements omitted it. Use `scipy==1.13.1` on Python 3.9 because `scipy==1.15.3` is incompatible with that interpreter.
6. Run `scripts/extend_distributed_timeout.py REPO` once. It idempotently changes only the distributed initialization timeout from 2 hours to 24 hours. Stop if the source has an unexpected form.
7. Run `scripts/launch_base_eval.sh` on the server from any directory. Supply explicit paths when they differ from the validated `aigc_1` defaults. The script performs preflight checks and launches all eight ranks with `nohup` plus `setsid`, so closing the client computer does not stop inference.
8. Monitor without restarting a healthy run. Inspect the printed PID, log path, GPU processes, and result line count. Completion requires no evaluation process and a `result.json` whose final summary reports `length: 1839`.
9. Run `scripts/verify_result.py RESULT_JSON`. Treat its independently recomputed episode metrics as authoritative. It rejects malformed JSON, duplicate episodes, missing episodes, inconsistent embedded summaries, and deviations outside the configured paper tolerances.
10. Report the exact repository commit, checkpoint revision, GPU count, result path, episode count, recomputed metrics, paper deltas, completion time, and any deviations from this recipe.

## Launch example

```bash
bash scripts/launch_base_eval.sh \
  --repo /mnt/nas-data-1/home/cjwu/code/JanusVLN \
  --env /mnt/nas-data-1/home/cjwu/.conda/envs/janusvln \
  --model /mnt/nas-data-1/home/cjwu/models/JanusVLN_Base \
  --output /mnt/nas-data-1/home/cjwu/results/janusvln/base_r2r_val_unseen \
  --log /mnt/nas-data-1/home/cjwu/logs/janusvln/eval_base_r2r_8gpu.log \
  --gpus 0,1,2,3,4,5,6,7 \
  --master-port 29550
```

If `result.json` already exists, preserve it. Use a new output directory for a clean rerun. Use `--resume` only after confirming that the existing rows belong to the same commit, checkpoint, split, and arguments.

## Acceptance criteria

- Evaluate exactly 1,839 unique R2R `val_unseen` episodes.
- Recompute NE, OS, SR, and SPL from episode rows rather than trusting only the appended summary.
- Compare with paper targets: NE 5.17, OS 58.0%, SR 52.8%, SPL 49.2%.
- Default acceptance bands are absolute NE difference at most 0.20 and OS/SR/SPL difference at most 1.0 percentage point.
- Do not describe a partial file, duplicated rows, or a failed final distributed gather as a completed reproduction.

## Safety

- Never delete an existing result automatically.
- Never launch a second evaluation for the same model and output while one is running.
- Never overwrite unrelated repository changes.
- Keep the evaluation detached from the SSH client and write all output to a persistent server path.
