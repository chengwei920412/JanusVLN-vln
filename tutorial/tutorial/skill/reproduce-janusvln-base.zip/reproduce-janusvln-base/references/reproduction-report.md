# JanusVLN Base 复现说明

## 1. 结论

JanusVLN Base 开源权重已在 `aigc_1` 的 8 张 NVIDIA A100-SXM4-80GB 上完成 R2R `val_unseen` 全量评测。共评测 1,839 个唯一 episode，无重复、无损坏记录。独立重算结果与程序末尾汇总一致，并且四项指标均处于本 Skill 的复现容差内。

官方资料：

- 代码仓库：<https://github.com/MIV-XJTU/JanusVLN>
- 论文：<https://arxiv.org/html/2509.22548>
- Base 权重：`misstl/JanusVLN_Base`

## 2. 固定版本

| 项目 | 本次使用值 |
|---|---|
| 服务器 | `aigc_1` |
| 仓库路径 | `/mnt/nas-data-1/home/cjwu/code/JanusVLN` |
| Git commit | `64ac8373c1e3c4a810a999cad536f633f2277d68` |
| Base 权重路径 | `/mnt/nas-data-1/home/cjwu/models/JanusVLN_Base` |
| Base 权重 revision | `33f932a4ea6bdc34afca9f5b79a8b4537cd02509` |
| 数据 split | R2R `val_unseen` |
| episode 数 | 1,839 |
| GPU | 8 × NVIDIA A100-SXM4-80GB |
| 驱动 | 580.82.07 |
| Python | 3.9 |

主要 Python 包：

| 包 | 版本 |
|---|---|
| torch | 2.5.1+cu124 |
| torchvision | 0.20.1+cu124 |
| torchaudio | 2.5.1+cu124 |
| transformers | 4.50.0 |
| accelerate | 1.4.0 |
| flash-attn | 2.7.1.post4 |
| habitat-lab | 0.2.4 |
| habitat-sim | 0.2.4 |
| qwen-vl-utils | 0.0.11 |
| numpy | 1.26.4 |
| scipy | 1.13.1 |
| fastdtw | 0.3.4 |

上游依赖文件指定的 SciPy 1.15.3 不支持 Python 3.9，本次改用 1.13.1。`fastdtw` 未完整列入上游安装要求，但运行需要，因此显式安装 0.3.4。Base 指标与论文高度吻合，说明这两项兼容处理没有造成可见的系统性偏差。

## 3. 数据布局

仓库中的 `data` 指向持久化数据目录：

```text
JanusVLN/data -> /mnt/nas-data-1/home/cjwu/datasets/janusvln/data
```

评测前确认以下内容存在：

```text
data/datasets/r2r/                 R2R_VLNCE_v1-3_preprocessed
data/scene_datasets/mp3d/         Matterport3D Habitat 场景和 navmesh
```

不得把缺失场景、子集数据或不同 split 的结果与论文表格直接比较。

## 4. 代码兼容处理

8 卡任务中不同 rank 的 episode 耗时不均衡，较快 rank 可能在最终聚合处等待超过上游默认的 2 小时，从而触发 NCCL 超时。将 `src/utils/dist.py` 中：

```python
timeout=datetime.timedelta(0, 7200)
```

改为：

```python
timeout=datetime.timedelta(hours=24)
```

该修改只延长分布式通信等待时间，不改变模型输入、动作生成、轨迹或指标公式。使用 `scripts/extend_distributed_timeout.py` 做幂等修改，并保留 Git diff 作为运行记录。

## 5. 运行参数

成功复现使用以下关键参数：

```text
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
torchrun --nproc_per_node=8 --master_port=29550
--model_path .../JanusVLN_Base
--habitat_config_path config/vln_r2r.yaml
--eval_split val_unseen
--num_history 8
--max_steps 400
--seed 42
```

模型解码采用贪心方式：`temperature=0`、`do_sample=False`、`num_beams=1`。GPU 算法未强制完全确定，因此极少数临界 episode 在不同硬件或软件栈上仍可能发生变化。

使用 Skill 内的后台启动脚本：

```bash
bash scripts/launch_base_eval.sh
```

脚本默认使用本说明中的 `aigc_1` 路径，可通过参数覆盖。它使用 `nohup` 和 `setsid` 脱离 SSH 会话，因此关闭本地电脑不会终止任务。脚本不会删除或覆盖已有结果；如确需续跑，先核对已有记录来源，再显式传入 `--resume`。

## 6. 完成判定与独立核验

本次结果文件：

```text
/mnt/nas-data-1/home/cjwu/results/janusvln/base_r2r_val_unseen/result.json
```

日志文件：

```text
/mnt/nas-data-1/home/cjwu/logs/janusvln/eval_base_r2r_8gpu.log
```

结果于 2026-08-15 18:13（Asia/Shanghai）写完。JSONL 共 1,840 个对象：1,839 条 episode 记录和 1 条最终汇总。验收时运行：

```bash
python scripts/verify_result.py \
  /mnt/nas-data-1/home/cjwu/results/janusvln/base_r2r_val_unseen/result.json
```

核验脚本重新从 episode 行计算均值，不仅信任程序写入的末尾 summary；同时检查 JSON 完整性、唯一性、数量和 summary 一致性。

## 7. 复现结果

| 指标 | 论文 Base | 本次独立重算 | 差值（实测−论文） | 结论 |
|---|---:|---:|---:|---|
| NE ↓ | 5.17 | 5.2856 | +0.1156 | 通过 |
| OS ↑ | 58.0% | 57.2594% | −0.7406 pp | 通过 |
| SR ↑ | 52.8% | 52.9636% | +0.1636 pp | 通过 |
| SPL ↑ | 49.2% | 49.0089% | −0.1911 pp | 通过 |

默认验收范围为：NE 绝对差不超过 0.20；OS、SR、SPL 绝对差不超过 1.0 个百分点。Base 四项全部通过，可以判定开源 Base 权重与论文结果相符。

程序写入的末尾汇总为：

```json
{"sucs_all": 0.5296356678009033, "spls_all": 0.49008902912108904, "oss_all": 0.5725938081741333, "ones_all": 5.285562515258789, "length": 1839}
```

## 8. 已知复现风险

1. 论文文字描述的转向角为 30°，开源 `config/vln_r2r.yaml` 使用 15°。本次遵循开源配置；这是论文描述与发布配置之间的可复现性差异。
2. BF16、FlashAttention 和默认 CUDA 算法不保证逐位确定。闭环导航会放大单步动作差异，3 米成功阈值也会使临界 episode 翻转。
3. 所有 Habitat simulator 的配置使用 `gpu_device_id: 0`，主要影响资源分配和性能；本次未发现它破坏 Base 指标。
4. 多卡数量主要影响耗时。不得在任务正常运行时重复启动；不同 GPU 数或进程划分可能通过数值路径间接引入极小差异。

## 9. 报告模板

完成一次复现后，至少报告：服务器、GPU 型号与数量、仓库 commit、权重 revision、数据 split、episode 完整性、运行参数、结果与日志路径、四项独立重算指标、论文差值，以及所有环境或代码偏离项。
