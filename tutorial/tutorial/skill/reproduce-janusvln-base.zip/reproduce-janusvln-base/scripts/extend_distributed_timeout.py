#!/usr/bin/env python3
"""Idempotently extend JanusVLN's distributed timeout to 24 hours."""

from __future__ import annotations

import argparse
from pathlib import Path


OLD = "timeout=datetime.timedelta(0, 7200))"
NEW = "timeout=datetime.timedelta(hours=24))"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path, help="JanusVLN repository root")
    args = parser.parse_args()

    target = args.repo.expanduser().resolve() / "src" / "utils" / "dist.py"
    if not target.is_file():
        raise SystemExit(f"missing file: {target}")

    source = target.read_text(encoding="utf-8")
    if NEW in source and OLD not in source:
        print(f"already patched: {target}")
        return 0
    if source.count(OLD) != 1:
        raise SystemExit(
            "unexpected dist.py content; expected exactly one 2-hour timeout. "
            "Inspect the repository instead of patching automatically."
        )

    target.write_text(source.replace(OLD, NEW, 1), encoding="utf-8")
    print(f"patched distributed timeout to 24 hours: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
