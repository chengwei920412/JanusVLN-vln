#!/usr/bin/env bash
set -euo pipefail

repo="/mnt/nas-data-1/home/cjwu/code/JanusVLN"
conda_env="/mnt/nas-data-1/home/cjwu/.conda/envs/janusvln"
model="/mnt/nas-data-1/home/cjwu/models/JanusVLN_Base"
output="/mnt/nas-data-1/home/cjwu/results/janusvln/base_r2r_val_unseen"
log="/mnt/nas-data-1/home/cjwu/logs/janusvln/eval_base_r2r_8gpu.log"
gpus="0,1,2,3,4,5,6,7"
master_port="29550"
resume="false"

usage() {
  printf '%s\n' "Usage: $0 [--repo PATH] [--env PATH] [--model PATH] [--output PATH]" \
    "          [--log PATH] [--gpus CSV] [--master-port PORT] [--resume]"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo) repo="$2"; shift 2 ;;
    --env) conda_env="$2"; shift 2 ;;
    --model) model="$2"; shift 2 ;;
    --output) output="$2"; shift 2 ;;
    --log) log="$2"; shift 2 ;;
    --gpus) gpus="$2"; shift 2 ;;
    --master-port) master_port="$2"; shift 2 ;;
    --resume) resume="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) printf 'Unknown argument: %s\n' "$1" >&2; usage >&2; exit 2 ;;
  esac
done

expected_commit="64ac8373c1e3c4a810a999cad536f633f2277d68"
expected_revision="33f932a4ea6bdc34afca9f5b79a8b4537cd02509"
[[ -d "$repo/.git" ]] || { printf 'Missing repository: %s\n' "$repo" >&2; exit 1; }
[[ -f "$repo/src/evaluation.py" ]] || { printf 'Missing evaluation entrypoint\n' >&2; exit 1; }
[[ -f "$repo/config/vln_r2r.yaml" ]] || { printf 'Missing R2R config\n' >&2; exit 1; }
[[ -x "$conda_env/bin/torchrun" ]] || { printf 'Missing torchrun in environment: %s\n' "$conda_env" >&2; exit 1; }
[[ -d "$model" ]] || { printf 'Missing Base checkpoint: %s\n' "$model" >&2; exit 1; }
[[ -e "$repo/data/datasets/r2r" ]] || { printf 'Missing R2R dataset under repo/data/datasets/r2r\n' >&2; exit 1; }
[[ -e "$repo/data/scene_datasets/mp3d" ]] || { printf 'Missing MP3D scenes under repo/data/scene_datasets/mp3d\n' >&2; exit 1; }

actual_commit="$(git -C "$repo" rev-parse HEAD)"
if [[ "$actual_commit" != "$expected_commit" ]]; then
  printf 'Repository commit mismatch: expected %s, got %s\n' "$expected_commit" "$actual_commit" >&2
  exit 1
fi
if ! grep -Fq 'timeout=datetime.timedelta(hours=24))' "$repo/src/utils/dist.py"; then
  printf 'The validated 24-hour distributed timeout patch is missing.\n' >&2
  exit 1
fi
if [[ ! -f "$model/.msc" ]] || ! grep -aFq "$expected_revision" "$model/.msc"; then
  printf 'Unable to verify Base checkpoint revision %s in %s/.msc\n' "$expected_revision" "$model" >&2
  exit 1
fi

"$conda_env/bin/python" - <<'PY'
import importlib.metadata as metadata
import sys

expected = {
    "torch": "2.5.1+cu124",
    "transformers": "4.50.0",
    "accelerate": "1.4.0",
    "flash-attn": "2.7.1.post4",
    "habitat-lab": "0.2.4",
    "habitat-sim": "0.2.4",
    "qwen-vl-utils": "0.0.11",
    "numpy": "1.26.4",
    "scipy": "1.13.1",
    "fastdtw": "0.3.4",
}
mismatches = []
if sys.version_info[:2] != (3, 9):
    mismatches.append(f"python: expected 3.9, got {sys.version_info.major}.{sys.version_info.minor}")
for package, wanted in expected.items():
    try:
        actual = metadata.version(package)
    except metadata.PackageNotFoundError:
        actual = "NOT_INSTALLED"
    if actual != wanted:
        mismatches.append(f"{package}: expected {wanted}, got {actual}")
if mismatches:
    raise SystemExit("Environment mismatch:\n" + "\n".join(mismatches))
PY

if pgrep -af 'src/evaluation.py.*JanusVLN_Base' >/dev/null 2>&1; then
  printf 'A JanusVLN Base evaluation is already running; refusing a duplicate launch.\n' >&2
  pgrep -af 'src/evaluation.py.*JanusVLN_Base' >&2 || true
  exit 1
fi

result="$output/result.json"
if [[ -s "$result" && "$resume" != "true" ]]; then
  printf 'Existing result preserved: %s\nUse a new output path or pass --resume after validating provenance.\n' "$result" >&2
  exit 1
fi

IFS=',' read -r -a gpu_list <<< "$gpus"
nproc="${#gpu_list[@]}"
if [[ "$nproc" -ne 8 ]]; then
  printf 'This validated recipe requires exactly 8 GPU IDs; got %s\n' "$gpus" >&2
  exit 1
fi
if [[ ! "$master_port" =~ ^[0-9]+$ ]] || (( master_port < 1024 || master_port > 65535 )); then
  printf 'Invalid master port: %s\n' "$master_port" >&2
  exit 1
fi

mkdir -p "$output" "$(dirname "$log")"
task_path="$conda_env/bin:/usr/local/cuda/bin:/usr/bin:/bin"
task_ld_library_path="${JANUSVLN_LD_LIBRARY_PATH:-${HOME}/lib/nvidia-580.82:${conda_env}/lib:/usr/lib/x86_64-linux-gnu}"
egl_vendor_file="${JANUSVLN_EGL_VENDOR_FILE:-/usr/share/glvnd/egl_vendor.d/10_nvidia.json}"

cd "$repo"
nohup setsid env \
  PATH="$task_path" \
  LD_LIBRARY_PATH="$task_ld_library_path" \
  __EGL_VENDOR_LIBRARY_FILENAMES="$egl_vendor_file" \
  CUDA_VISIBLE_DEVICES="$gpus" \
  MAGNUM_LOG=quiet \
  HABITAT_SIM_LOG=quiet \
  TOKENIZERS_PARALLELISM=false \
  "$conda_env/bin/torchrun" \
    --nproc_per_node="$nproc" \
    --master_port="$master_port" \
    src/evaluation.py \
    --model_path "$model" \
    --habitat_config_path config/vln_r2r.yaml \
    --eval_split val_unseen \
    --output_path "$output" \
    --num_history 8 \
    --max_steps 400 \
    --seed 42 \
  </dev/null >"$log" 2>&1 &

launch_pid=$!
printf 'Started detached JanusVLN Base evaluation.\nPID: %s\nLog: %s\nResult: %s\n' \
  "$launch_pid" "$log" "$result"
