#!/usr/bin/env python3
"""Validate JanusVLN JSONL output and independently recompute Base metrics."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


PAPER = {"NE": 5.17, "OS": 58.0, "SR": 52.8, "SPL": 49.2}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("result", type=Path, help="Path to result.json JSONL file")
    parser.add_argument("--expected-episodes", type=int, default=1839)
    parser.add_argument("--ne-tolerance", type=float, default=0.20)
    parser.add_argument("--rate-tolerance", type=float, default=1.0)
    return parser.parse_args()


def mean(rows: list[dict], key: str) -> float:
    values = [float(row[key]) for row in rows]
    if not all(math.isfinite(value) for value in values):
        raise ValueError(f"non-finite value in {key}")
    return sum(values) / len(values)


def main() -> int:
    args = parse_args()
    path = args.result.expanduser().resolve()
    if not path.is_file():
        raise SystemExit(f"missing result file: {path}")

    records: list[dict] = []
    for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw.strip():
            continue
        try:
            item = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise SystemExit(f"invalid JSON at line {line_number}: {exc}") from exc
        if not isinstance(item, dict):
            raise SystemExit(f"line {line_number} is not a JSON object")
        records.append(item)

    episodes = [row for row in records if "success" in row]
    summaries = [row for row in records if "length" in row and "success" not in row]
    required = {"episode_id", "scene_id", "ne", "os", "success", "spl", "steps"}
    for index, row in enumerate(episodes, 1):
        missing = required.difference(row)
        if missing:
            raise SystemExit(f"episode row {index} is missing: {sorted(missing)}")

    identities = [(str(row["scene_id"]), str(row["episode_id"])) for row in episodes]
    duplicates = len(identities) - len(set(identities))
    if len(episodes) != args.expected_episodes or duplicates:
        raise SystemExit(
            f"episode integrity failed: rows={len(episodes)}, expected={args.expected_episodes}, "
            f"duplicates={duplicates}"
        )
    if len(summaries) != 1:
        raise SystemExit(f"expected exactly one final summary, found {len(summaries)}")

    metrics = {
        "NE": mean(episodes, "ne"),
        "OS": 100.0 * mean(episodes, "os"),
        "SR": 100.0 * mean(episodes, "success"),
        "SPL": 100.0 * mean(episodes, "spl"),
    }
    embedded = summaries[0]
    embedded_metrics = {
        "NE": float(embedded["ones_all"]),
        "OS": 100.0 * float(embedded["oss_all"]),
        "SR": 100.0 * float(embedded["sucs_all"]),
        "SPL": 100.0 * float(embedded["spls_all"]),
    }
    if int(embedded["length"]) != len(episodes):
        raise SystemExit("embedded summary length does not match episode rows")
    for key in metrics:
        if not math.isclose(metrics[key], embedded_metrics[key], abs_tol=1e-4):
            raise SystemExit(
                f"embedded {key} mismatch: recomputed={metrics[key]:.8f}, "
                f"embedded={embedded_metrics[key]:.8f}"
            )

    print(f"Episodes: {len(episodes)} unique, 0 duplicates")
    print("Metric  Recomputed  Paper   Delta")
    for key in ("NE", "OS", "SR", "SPL"):
        suffix = "" if key == "NE" else "%"
        print(
            f"{key:<6}  {metrics[key]:>10.4f}{suffix:<1}  "
            f"{PAPER[key]:>6.2f}{suffix:<1}  {metrics[key] - PAPER[key]:>+7.4f}"
        )

    failures = []
    if abs(metrics["NE"] - PAPER["NE"]) > args.ne_tolerance:
        failures.append("NE")
    for key in ("OS", "SR", "SPL"):
        if abs(metrics[key] - PAPER[key]) > args.rate_tolerance:
            failures.append(key)
    if failures:
        print(f"FAIL: outside tolerance: {', '.join(failures)}")
        return 1
    print("PASS: complete output and all metrics within configured paper tolerances")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
